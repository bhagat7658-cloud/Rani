# Proud Rani — Premium UI

Polished safety-app prototype matching the supplied reference layout:
Splash, Login, Home, Report Incident, Safe Places, Resources, Community and Profile.
Includes the supplied Proud Rani logo and SOS/emergency actions.

Build with Java 17 / Gradle 8.10.2.
