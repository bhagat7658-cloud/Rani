# Proud Rani — Premium UI

Reference-inspired women safety app UI with splash, login, home, SOS, report, safe places, resources, community and profile screens.

The project targets Java/Kotlin 17 and includes a GitHub Actions workflow.
