package com.proudrani.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val pink = Color.rgb(217,27,98)
    private val bg = Color.rgb(255,248,250)
    private val text = Color.rgb(36,33,38)
    private val muted = Color.rgb(126,116,122)
    private val pad get() = (resources.displayMetrics.density * 16).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        splash()
    }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        return root
    }

    private fun splash() {
        val l = base(); l.gravity = Gravity.CENTER
        val logo = ImageView(this).apply { setImageResource(com.proudrani.app.R.drawable.proud_rani_logo); scaleType = ImageView.ScaleType.CENTER_INSIDE }
        l.addView(logo, LinearLayout.LayoutParams(-1, 330))
        val title = tv("Safer Spaces\nBrighter Tomorrows", 20, text, true); title.gravity = Gravity.CENTER
        l.addView(title)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { progress = 55 }
        l.addView(bar, LinearLayout.LayoutParams(170, 10).apply { topMargin = 28 })
        setContentView(l)
        l.postDelayed({ login() }, 1500)
    }

    private fun login() {
        val l = base(); l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        l.setPadding(pad, 38, pad, pad)
        val logo = ImageView(this).apply { setImageResource(R.drawable.proud_rani_logo); scaleType = ImageView.ScaleType.CENTER_INSIDE }
        l.addView(logo, LinearLayout.LayoutParams(-1, 190))
        l.addView(tv("Welcome to Proud Rani", 25, text, true).apply { gravity=Gravity.CENTER })
        l.addView(tv("A safer, stronger, more equal tomorrow.", 14, muted, false).apply { gravity=Gravity.CENTER; setPadding(0,8,0,22) })
        l.addView(btn("G   Continue with Google", pink) { home() })
        l.addView(tv("OR", 13, muted, true).apply { gravity=Gravity.CENTER; setPadding(0,16,0,10) })
        l.addView(edit("Enter mobile number"))
        l.addView(btn("Send OTP", Color.rgb(244,156,186)) { home() })
        l.addView(tv("By continuing, you agree to our\nTerms & Privacy Policy", 11, muted, false).apply { gravity=Gravity.CENTER; setPadding(0,18,0,0) })
        setContentView(l)
    }

    private fun home() {
        val l=base(); l.setPadding(pad, 22, pad, 0)
        val head=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val h=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; layoutParams=LinearLayout.LayoutParams(0, -2, 1f)}
        h.addView(tv("Hello Rani 👋",24,text,true)); h.addView(tv("You are not alone.",13,muted,false))
        head.addView(h); head.addView(tv("♧",28,pink,true))
        l.addView(head)
        val grid=GridLayout(this).apply{columnCount=2; rowCount=2; setPadding(0,18,0,8)}
        grid.addView(action("🚨\nSOS\nEmergency",Color.rgb(235,49,55)){sos()})
        grid.addView(action("▣\nReport\nIncident",Color.rgb(249,211,223)){report()})
        grid.addView(action("●\nFind\nSafe Places",Color.rgb(118,83,232)){map()})
        grid.addView(action("⚖\nLegal\nSupport",Color.rgb(46,175,105)){resourcesPage()})
        l.addView(grid, LinearLayout.LayoutParams(-1, 270))
        l.addView(tv("Quick Resources",19,text,true).apply{setPadding(4,4,0,8)})
        listRow("☎  Women Helpline Numbers","Important contact numbers"){resourcesPage()}
        listRow("✿  Mental Health Support","Counselling and support"){resourcesPage()}
        listRow("✓  Know Your Rights","Guides and resources"){resourcesPage()}
        listRow("★  Safety Tips","Practical safety guidance"){resourcesPage()}
        bottom(l,0)
        setContentView(l)
    }

    private fun report(){ simplePage("Report Incident", listOf("👗  Harassment|Street, workplace, online etc.","✊  Assault|Physical or sexual violence","◉  Stalking|Repeated unwanted attention","•••  Others|Any other incident"), "Next") { toast("Report flow ready — details can be added next") } }
    private fun map(){ simplePage("Safe Places", listOf("📍  Women Help Centre|Nearby verified support","🏥  Hospital|Emergency medical support","👮  Police Station|Official emergency support","🏠  Shelter / NGO|Verified support locations"), "Get Directions") { toast("Map integration can be connected next") } }
    private fun resourcesPage(){ simplePage("Resources & Help", listOf("☎  Emergency Helplines|Important contact numbers","⚖  Legal Aid|Free legal support","♥  Mental Health Support|Counselling and support","👥  NGOs & Support Groups|Verified organisations","▣  Safety Guides|Tips and resources","▦  Government Schemes|Policies for women"), "") }
    private fun community(){ simplePage("Community", listOf("Rani123|Sharing my story because I want other women to know they are not alone.","SafeTogether|Important safety tips for travelling in the city.","Aisha|A space where we can support each other."), "") }
    private fun profile(){ simplePage("My Profile", listOf("▣  My Reports|Your submitted reports","📍  Saved Places|Places you saved","💬  My Posts|Your community posts","☎  Emergency Contacts|Trusted contacts","⚙  App Settings|Preferences","?  Help & Feedback|Support"), "Logout") }

    private fun simplePage(title:String, rows:List<String>, action:String, click:(()->Unit)?=null){
        val l=base(); l.setPadding(pad,22,pad,0)
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        bar.addView(tv("‹",34,text,true)); bar.addView(tv(title,20,text,true).apply{gravity=Gravity.CENTER; layoutParams=LinearLayout.LayoutParams(0,70,1f)})
        bar.addView(tv("⌕",27,text,true)); l.addView(bar)
        rows.forEach{r-> val p=r.split("|",limit=2); listRow(p[0], if(p.size>1)p[1] else ""){click?.invoke()}; }
        if(action.isNotEmpty()) l.addView(btn(action,pink){click?.invoke()})
        bottom(l, if(title=="Community")3 else if(title=="My Profile")4 else 2)
        setContentView(l)
    }

    private fun bottom(parent:LinearLayout, selected:Int){
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(0,8,0,8)}
        val labels=listOf("⌂\nHome","⌖\nMap","▣\nReport","♣\nCommunity","●\nProfile")
        labels.forEachIndexed{i,s-> val v=tv(s,11,if(i==selected)pink else muted,true);v.gravity=Gravity.CENTER;v.setPadding(6,8,6,4);nav.addView(v,LinearLayout.LayoutParams(0,62,1f));v.setOnClickListener{when(i){0->home();1->map();2->report();3->community();4->profile()}} }
        parent.addView(nav,LinearLayout.LayoutParams(-1,70).apply{gravity=Gravity.BOTTOM})
    }

    private fun action(label:String,color:Int,click:()->Unit):TextView{ val v=tv(label,15,Color.WHITE,true);v.gravity=Gravity.CENTER;v.setBackground(round(color,20));v.setOnClickListener{click()};v.setPadding(8,10,8,10); val lp=GridLayout.LayoutParams().apply{width=0;height=125;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(5,5,5,5)};v.layoutParams=lp;return v }
    private fun listRow(a:String,b:String,click:()->Unit){ val box=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(16,8,12,8);setBackground(round(Color.WHITE,18));setOnClickListener{click()}};val t=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutParams=LinearLayout.LayoutParams(0,-2,1f)};t.addView(tv(a,15,text,true));t.addView(tv(b,12,muted,false));box.addView(t);box.addView(tv("›",27,muted,true));root.addView(box,LinearLayout.LayoutParams(-1,65).apply{bottomMargin=8}) }
    private fun edit(hint:String):EditText=EditText(this).apply{setHint(hint);textSize=15f;setPadding(18,0,18,0);background=round(Color.WHITE,18);layoutParams=LinearLayout.LayoutParams(-1,56).apply{bottomMargin=10}}
    private fun btn(label:String,color:Int,click:()->Unit)=TextView(this).apply{ text=label;textSize=15f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setTypeface(null,1);background=round(color,18);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,58).apply{topMargin=8} }
    private fun tv(s:String,size:Int,c:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(c);if(bold)setTypeface(null,1)}
    private fun round(c:Int,r:Float)=android.graphics.drawable.GradientDrawable().apply{setColor(c);cornerRadius=r}
    private fun sos(){AlertDialog.Builder(this).setTitle("SOS Emergency").setMessage("Are you in immediate danger? You can call emergency services first.").setNegativeButton("Cancel",null).setPositiveButton("Call 112"){_,_->dial("112")}.show()}
    private fun dial(n:String){startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
