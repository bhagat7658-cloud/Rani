# Proud Rani — Premium Women Safety App

Android MVP inspired by the supplied Proud Rani reference design.

## Included
- Premium pink/white UI with custom-drawn icons (no emoji-only navigation)
- Animated Proud Rani splash screen and logo
- Login/entry screen
- Home dashboard with SOS, Report, Safe Places and Legal Support
- SOS dialog with 112 calling and location-share handoff
- Incident reporting flow
- Safe Places map-style screen with directions handoff
- Resources & Help
- Community feed
- Profile screen
- Functional bottom navigation
- Java 17 / Gradle Actions build configuration

## Build
Open the project in Android Studio or run the included GitHub Actions workflow.
