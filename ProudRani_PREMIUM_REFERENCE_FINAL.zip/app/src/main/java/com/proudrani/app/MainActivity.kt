package com.proudrani.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val pink = Color.rgb(215, 29, 95)
    private val pinkDark = Color.rgb(157, 18, 67)
    private val pinkLight = Color.rgb(255, 232, 240)
    private val pageBg = Color.rgb(255, 248, 251)
    private val ink = Color.rgb(35, 31, 34)
    private val muted = Color.rgb(126, 116, 122)
    private val white = Color.WHITE
    private val red = Color.rgb(228, 50, 57)
    private val purple = Color.rgb(113, 77, 222)
    private val green = Color.rgb(45, 171, 102)
    private val border = Color.rgb(244, 224, 232)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private val pad get() = dp(18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pageBg
        window.navigationBarColor = pageBg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        splash()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(pageBg)
    }

    private fun screen(body: View, selected: Int? = null): View {
        val root = FrameLayout(this)
        root.addView(body, FrameLayout.LayoutParams(-1, -1))
        if (selected != null) bottomNav(root, selected)
        return root
    }

    private fun splash() {
        val root = base().apply { gravity = Gravity.CENTER; setPadding(pad, dp(26), pad, dp(30)) }
        val glow = View(this).apply { background = rounded(pinkLight, 180) }
        root.addView(glow, LinearLayout.LayoutParams(dp(250), dp(250)))
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.proud_rani_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            translationY = -dp(130).toFloat()
            alpha = 0f
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(320), dp(320)).apply { topMargin = -dp(250) })
        val title = label("Safer Spaces\nBrighter Tomorrows", 20, ink, true).apply {
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; alpha = 0f
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = -dp(20) })
        val line = View(this).apply { background = rounded(pink, 8); scaleX = 0f; pivotX = 0f }
        root.addView(line, LinearLayout.LayoutParams(dp(140), dp(4)).apply { topMargin = dp(22) })
        setContentView(root)
        root.post {
            logo.animate().alpha(1f).translationY(0f).setDuration(650).start()
            title.animate().alpha(1f).setDuration(650).setStartDelay(180).start()
            line.animate().scaleX(1f).setDuration(800).setStartDelay(300).start()
        }
        root.postDelayed({ login() }, 1900)
    }

    private fun login() {
        val body = base().apply { setPadding(pad, dp(26), pad, dp(20)); gravity = Gravity.TOP }
        val logo = ImageView(this).apply { setImageResource(R.drawable.proud_rani_logo); scaleType = ImageView.ScaleType.CENTER_INSIDE }
        body.addView(logo, LinearLayout.LayoutParams(-1, dp(185)))
        body.addView(label("Welcome to Proud Rani", 24, ink, true).apply { gravity = Gravity.CENTER })
        body.addView(label("A safer, stronger, more equal tomorrow.", 13, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(20)) })
        body.addView(primary("Continue with Google", pink) { home() })
        body.addView(label("OR", 11, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(8)) })
        body.addView(edit("Enter mobile number"))
        body.addView(primary("Send OTP", Color.rgb(247, 153, 184), pinkDark) { home() })
        body.addView(label("By continuing, you agree to our\nTerms & Privacy Policy", 11, muted, false).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; setPadding(0, dp(15), 0, 0) })
        setContentView(body)
    }

    private fun home() {
        val body = base().apply { setPadding(pad, dp(18), pad, dp(92)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val greeting = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        greeting.addView(label("Hello Rani 👋", 23, ink, true))
        greeting.addView(label("You are not alone.", 13, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        head.addView(greeting)
        head.addView(iconButton(Icon.BELL, pinkLight, pink) { toast("You're safe. Notifications are clear.") })
        body.addView(head)

        body.addView(sectionTitle("Your safety, one tap away", "Quick actions"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22); bottomMargin = dp(7) })
        val grid = GridLayout(this).apply { columnCount = 2 }
        grid.addView(action("SOS", "Emergency", red, Icon.SOS) { sos() })
        grid.addView(action("Report", "Incident", pink, Icon.REPORT) { report() })
        grid.addView(action("Find", "Safe Places", purple, Icon.MAP) { map() })
        grid.addView(action("Legal", "Support", green, Icon.LEGAL) { resourcesPage() })
        body.addView(grid, LinearLayout.LayoutParams(-1, dp(235)))

        val qr = sectionTitle("Quick Resources", "See all")
        qr.getChildAt(1).setOnClickListener { resourcesPage() }
        body.addView(qr, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(6) })
        resource(body, Icon.PHONE, "Women Helpline Numbers", "Important contact numbers") { resourcesPage() }
        resource(body, Icon.HEART, "Mental Health Support", "Counselling and support") { resourcesPage() }
        resource(body, Icon.LEGAL, "Know Your Rights", "Guides and resources") { resourcesPage() }
        resource(body, Icon.SHIELD, "Safety Tips", "Practical safety guidance") { resourcesPage() }
        setContentView(screen(body, 0))
    }

    private fun report() {
        val body = base().apply { setPadding(pad, dp(12), pad, dp(92)) }
        topBar(body, "Report Incident")
        body.addView(label("Choose what best describes what happened.", 13, muted, false).apply { setPadding(0, dp(6), 0, dp(16)) })
        incident(body, Icon.SHIELD, "Harassment", "Street, workplace, online etc.")
        incident(body, Icon.HAND, "Assault", "Physical or sexual violence")
        incident(body, Icon.EYE, "Stalking", "Repeated unwanted attention")
        incident(body, Icon.MORE, "Others", "Any other incident")
        body.addView(primary("Continue", pink) { reportDetails() })
        setContentView(screen(body, 2))
    }

    private fun reportDetails() {
        val body = base().apply { setPadding(pad, dp(12), pad, dp(92)) }
        topBar(body, "Incident Details")
        body.addView(label("You can share only what you are comfortable sharing.", 13, muted, false).apply { setPadding(0, dp(6), 0, dp(14)) })
        val desc = EditText(this).apply { hint = "Tell us what happened…"; gravity = Gravity.TOP; setPadding(dp(16), dp(15), dp(16), dp(15)); minLines = 6; background = rounded(white, 18); textSize = 14f }
        body.addView(desc, LinearLayout.LayoutParams(-1, dp(150)))
        body.addView(primary("Submit Report", pink) { toast("Report saved. Our team can follow up from the backend.") })
        body.addView(outline("Save & finish later") { toast("Saved on this device") })
        setContentView(screen(body, 2))
    }

    private fun map() {
        val body = base().apply { setPadding(0, dp(10), 0, dp(92)) }
        topBar(body, "Safe Places", true)
        val search = edit("Search safe places…")
        body.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(pad, dp(4), pad, dp(9)) })
        body.addView(SafeMapView(this), LinearLayout.LayoutParams(-1, dp(405)))
        val card = elevated().apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(16)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(iconButton(Icon.PHONE, pinkLight, pink) { toast("Calling support") })
        val cp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        cp.addView(label("Women Help Centre", 16, ink, true)); cp.addView(label("2.1 km  •  Open 24x7", 12, green, true).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(cp)
        card.addView(row)
        card.addView(primary("Get Directions", pink) { openMaps() })
        body.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(pad, dp(8), pad, 0) })
        setContentView(screen(body, 1))
    }

    private fun resourcesPage() {
        val body = base().apply { setPadding(pad, dp(12), pad, dp(92)) }
        topBar(body, "Resources & Help")
        body.addView(label("Verified information and support, all in one place.", 13, muted, false).apply { setPadding(0, dp(5), 0, dp(13)) })
        resource(body, Icon.PHONE, "Emergency Helplines", "112 • Women Helpline 181") { dial("112") }
        resource(body, Icon.LEGAL, "Legal Aid", "Free legal support") { toast("Legal support section") }
        resource(body, Icon.HEART, "Mental Health Support", "Counselling and support") { toast("Support section") }
        resource(body, Icon.GROUP, "NGOs & Support Groups", "Verified organisations") { toast("Support groups") }
        resource(body, Icon.BOOK, "Safety Guides", "Tips and resources") { toast("Safety guides") }
        resource(body, Icon.BUILDING, "Government Schemes", "Policies for women") { toast("Government schemes") }
        setContentView(screen(body, 2))
    }

    private fun community() {
        val body = base().apply { setPadding(pad, dp(12), pad, dp(92)) }
        topBar(body, "Community", false, true)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(12)) }
        listOf("All", "Discussions", "Support", "Stories").forEachIndexed { i, s ->
            val c = TextView(this).apply { text = s; textSize = 11f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); setTextColor(if (i == 0) white else muted); background = rounded(if (i == 0) pink else white, 18); setPadding(dp(15), dp(8), dp(15), dp(8)) }
            chips.addView(c, LinearLayout.LayoutParams(-2, dp(36)).apply { rightMargin = dp(7) })
        }
        body.addView(chips)
        post(body, "Rani123", "2 hours ago", "Sharing my story because I want other women to know they are not alone. 💜", "124   ♡   18   ↗")
        post(body, "SafeTogether", "5 hours ago", "Some important safety tips for travelling in the city. Let's keep each other safe! ✨", "86   ♡   10   ↗")
        post(body, "Aisha", "1 day ago", "This app is amazing. Finally, a space where we can support each other. ❤️", "210   ♡   25   ↗")
        setContentView(screen(body, 3))
    }

    private fun profile() {
        val body = base().apply { setPadding(pad, dp(12), pad, dp(92)) }
        topBar(body, "My Profile", false, false, true)
        val h = elevated().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        val avatar = TextView(this).apply { text = "R"; textSize = 24f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); setTextColor(pinkDark); background = rounded(pinkLight, 50) }
        h.addView(avatar, LinearLayout.LayoutParams(dp(70), dp(70)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        info.addView(label("Rani", 19, ink, true)); info.addView(label("+91 98765 43210", 12, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        h.addView(info); h.addView(iconButton(Icon.SETTINGS, white, muted) { toast("Settings") })
        body.addView(h, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        resource(body, Icon.REPORT, "My Reports", "Your submitted reports") { toast("My reports") }
        resource(body, Icon.MAP, "Saved Places", "Places you saved") { map() }
        resource(body, Icon.COMMUNITY, "My Posts", "Your community posts") { community() }
        resource(body, Icon.PHONE, "Emergency Contacts", "Trusted contacts") { resourcesPage() }
        resource(body, Icon.SETTINGS, "App Settings", "Preferences") { toast("Settings") }
        resource(body, Icon.HELP, "Help & Feedback", "Support") { resourcesPage() }
        body.addView(primary("Logout", pinkLight, pinkDark) { login() })
        setContentView(screen(body, 4))
    }

    private fun sos() {
        AlertDialog.Builder(this)
            .setTitle("SOS Emergency")
            .setMessage("If you are in immediate danger, call emergency services first. You can also share your location with your trusted responders.")
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Share location") { _, _ -> shareLocation() }
            .setPositiveButton("Call 112") { _, _ -> dial("112") }
            .show()
    }

    private fun shareLocation() {
        val text = "Proud Rani SOS — I need help. My location: https://maps.google.com/?q=32.73,74.87"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Share emergency location"))
    }

    private fun openMaps() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:32.73,74.87?q=Women+Help+Centre")))
    }

    private fun incident(parent: LinearLayout, icon: Icon, title: String, subtitle: String) {
        val box = elevated().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(10), dp(10)); setOnClickListener { toast("Selected: $title") } }
        box.addView(iconView(icon, pinkLight, pink, 48))
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        copy.addView(label(title, 16, ink, true)); copy.addView(label(subtitle, 12, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        box.addView(copy); box.addView(iconView(Icon.CHEVRON, Color.TRANSPARENT, muted, 28))
        parent.addView(box, LinearLayout.LayoutParams(-1, dp(76)).apply { bottomMargin = dp(10) })
    }

    private fun resource(parent: LinearLayout, icon: Icon, title: String, subtitle: String, click: () -> Unit) {
        val box = elevated().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(9), dp(8), dp(8), dp(8)); setOnClickListener { click() } }
        box.addView(iconView(icon, pinkLight, pink, 44))
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        copy.addView(label(title, 14, ink, true)); copy.addView(label(subtitle, 11, muted, false).apply { setPadding(0, dp(2), 0, 0) })
        box.addView(copy); box.addView(iconView(Icon.CHEVRON, Color.TRANSPARENT, muted, 25))
        parent.addView(box, LinearLayout.LayoutParams(-1, dp(67)).apply { bottomMargin = dp(7) })
    }

    private fun post(parent: LinearLayout, name: String, time: String, message: String, stats: String) {
        val card = elevated().apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = name.first().uppercase(); textSize = 14f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); setTextColor(pinkDark); background = rounded(pinkLight, 50) }, LinearLayout.LayoutParams(dp(38), dp(38)))
        val who = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        who.addView(label(name, 13, ink, true)); who.addView(label(time, 10, muted, false).apply { setPadding(0, dp(2), 0, 0) })
        head.addView(who); head.addView(iconView(Icon.MORE, Color.TRANSPARENT, muted, 24)); card.addView(head)
        card.addView(label(message, 13, ink, false).apply { setPadding(0, dp(10), 0, dp(9)) }); card.addView(label(stats, 11, muted, true))
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun action(title: String, subtitle: String, color: Int, icon: Icon, click: () -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(10), dp(8), dp(8)); background = rounded(color, 20); elevation = dp(3).toFloat(); setOnClickListener { click() } }
        box.addView(iconView(icon, Color.argb(35,255,255,255), white, 42))
        box.addView(label(title, 15, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        box.addView(label(subtitle, 11, Color.argb(225,255,255,255), false).apply { gravity = Gravity.CENTER })
        val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)).apply { width = 0; height = dp(108); setMargins(dp(5), dp(5), dp(5), dp(5)) }
        box.layoutParams = lp
        return box
    }

    private fun sectionTitle(left: String, right: String): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(left, 17, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label(right, 12, pink, true))
        return row
    }

    private fun topBar(parent: LinearLayout, title: String, search: Boolean = false, searchOnly: Boolean = false, settings: Boolean = false) {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(7)) }
        bar.addView(iconView(Icon.BACK, Color.TRANSPARENT, ink, 42).apply { setOnClickListener { onBackPressedDispatcher.onBackPressed() } })
        bar.addView(label(title, 18, ink, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, dp(48), 1f))
        val ic = if (settings) Icon.SETTINGS else if (search || searchOnly) Icon.SEARCH else null
        if (ic != null) bar.addView(iconView(ic, Color.TRANSPARENT, muted, 40)) else bar.addView(Space(this), LinearLayout.LayoutParams(dp(40), dp(48)))
        parent.addView(bar)
    }

    private fun bottomNav(root: FrameLayout, selected: Int) {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = white; elevation = dp(12).toFloat(); setPadding(dp(5), dp(4), dp(5), dp(3)) }
        val items = listOf("Home" to Icon.HOME, "Map" to Icon.MAP, "Report" to Icon.REPORT, "Community" to Icon.COMMUNITY, "Profile" to Icon.PROFILE)
        items.forEachIndexed { i, item ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { when(i){0->home();1->map();2->report();3->community();4->profile()} } }
            col.addView(iconView(item.second, if(i==selected) pinkLight else Color.TRANSPARENT, if(i==selected) pink else muted, 29))
            col.addView(label(item.first, 10, if(i==selected) pink else muted, i==selected))
            nav.addView(col, LinearLayout.LayoutParams(0, dp(60), 1f))
        }
        root.addView(nav, FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM))
    }

    private fun iconButton(icon: Icon, bg: Int, fg: Int, click: () -> Unit): View = iconView(icon, bg, fg, 42).apply { setOnClickListener { click() } }

    private fun iconView(icon: Icon, bg: Int, fg: Int, size: Int): IconView = IconView(this, icon, bg, fg, size)

    private fun primary(title: String, color: Int, textColor: Int = white, click: () -> Unit): TextView = TextView(this).apply {
        text = title; textSize = 14f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); setTextColor(textColor); background = gradient(color); elevation = dp(2).toFloat(); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) }
    }

    private fun outline(title: String, click: () -> Unit): TextView = TextView(this).apply { text = title; textSize = 14f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); setTextColor(pink); background = rounded(white, 18); elevation = dp(1).toFloat(); setOnClickListener { click() }; layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) } }

    private fun edit(hint: String): EditText = EditText(this).apply { this.hint = hint; textSize = 14f; setSingleLine(true); setPadding(dp(16), 0, dp(16), 0); background = rounded(white, 18); elevation = dp(1).toFloat() }

    private fun label(s: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) else typeface = Typeface.create("sans-serif", Typeface.NORMAL) }

    private fun elevated() = LinearLayout(this).apply { background = rounded(white, 18); elevation = dp(2).toFloat() }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), if (color == white) border else Color.TRANSPARENT) }
    private fun gradient(color: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color, blend(color, Color.WHITE, .12f))).apply { cornerRadius = dp(18).toFloat() }
    private fun blend(a: Int, b: Int, t: Float): Int { val r=(Color.red(a)+(Color.red(b)-Color.red(a))*t).roundToInt(); val g=(Color.green(a)+(Color.green(b)-Color.green(a))*t).roundToInt(); val bl=(Color.blue(a)+(Color.blue(b)-Color.blue(a))*t).roundToInt(); return Color.rgb(r,g,bl) }

    private fun dial(number: String) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    enum class Icon { HOME, MAP, REPORT, COMMUNITY, PROFILE, SOS, LEGAL, PHONE, HEART, SHIELD, HAND, EYE, MORE, BOOK, GROUP, BUILDING, SETTINGS, HELP, BACK, SEARCH, CHEVRON, BELL }

    private class IconView(context: Context, private val icon: Icon, private val bgColor: Int, private val fg: Int, private val sizeDp: Int) : View(context) {
        private val d = resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1.8f*d; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onMeasure(w: Int, h: Int) { val s=(sizeDp*d).roundToInt(); setMeasuredDimension(s,s) }
        override fun onDraw(c: Canvas) {
            super.onDraw(c); val w=width.toFloat(); val h=height.toFloat(); val cx=w/2; val cy=h/2; val r=w*.42f
            if (bgColor != Color.TRANSPARENT) { fill.color=bgColor; c.drawCircle(cx,cy,r,fill) }
            p.color=fg; p.strokeWidth=1.8f*d; fill.color=fg
            when(icon){
                Icon.HOME -> { val path=Path().apply{moveTo(cx-r*.55f,cy);lineTo(cx,cy-r*.55f);lineTo(cx+r*.55f,cy);moveTo(cx-r*.4f,cy-r*.08f);lineTo(cx-r*.4f,cy+r*.55f);lineTo(cx+r*.4f,cy+r*.55f);lineTo(cx+r*.4f,cy-r*.08f)};c.drawPath(path,p);c.drawLine(cx-r*.15f,cy+r*.55f,cx-r*.15f,cy+r*.12f,p);c.drawLine(cx-r*.15f,cy+r*.12f,cx+r*.15f,cy+r*.12f,p);c.drawLine(cx+r*.15f,cy+r*.12f,cx+r*.15f,cy+r*.55f,p)}
                Icon.MAP -> {c.drawCircle(cx,cy-r*.15f,r*.55f,p);c.drawLine(cx,cy+r*.4f,cx,cy+r*.78f,p);c.drawCircle(cx,cy-r*.15f,r*.18f,p)}
                Icon.REPORT -> {c.drawRoundRect(cx-r*.5f,cy-r*.62f,cx+r*.5f,cy+r*.62f,r*.08f,r*.08f,p);c.drawLine(cx-r*.25f,cy-r*.2f,cx+r*.25f,cy-r*.2f,p);c.drawLine(cx-r*.25f,cy+r*.08f,cx+r*.25f,cy+r*.08f,p);c.drawLine(cx-r*.25f,cy+r*.36f,cx+r*.1f,cy+r*.36f,p)}
                Icon.COMMUNITY, Icon.GROUP -> {c.drawCircle(cx,cy-r*.25f,r*.22f,p);c.drawCircle(cx-r*.48f,cy-r*.12f,r*.17f,p);c.drawCircle(cx+r*.48f,cy-r*.12f,r*.17f,p);c.drawArc(cx-r*.38f,cy+r*.05f,cx+r*.38f,cy+r*.72f,200f,140f,false,p);c.drawArc(cx-r*.72f,cy+r*.05f,cx-r*.18f,cy+r*.58f,210f,110f,false,p);c.drawArc(cx+r*.18f,cy+r*.05f,cx+r*.72f,cy+r*.58f,220f,110f,false,p)}
                Icon.PROFILE -> {c.drawCircle(cx,cy-r*.25f,r*.23f,p);c.drawArc(cx-r*.55f,cy+r*.02f,cx+r*.55f,cy+r*.72f,200f,140f,false,p)}
                Icon.SOS -> {c.drawCircle(cx,cy,r*.7f,p);c.drawLine(cx,cy-r*.3f,cx,cy+r*.1f,p);c.drawCircle(cx,cy+r*.35f,.9f*d,fill)}
                Icon.LEGAL -> {c.drawLine(cx-r*.55f,cy-r*.4f,cx+r*.55f,cy-r*.4f,p);c.drawLine(cx,cy-r*.65f,cx,cy+r*.48f,p);c.drawLine(cx-r*.7f,cy+r*.55f,cx+r*.7f,cy+r*.55f,p);c.drawLine(cx-r*.45f,cy-r*.35f,cx-r*.7f,cy+r*.12f,p);c.drawLine(cx+r*.45f,cy-r*.35f,cx+r*.7f,cy+r*.12f,p);c.drawArc(cx-r*.85f,cy-r*.02f,cx-r*.55f,cy+r*.3f,0f,180f,false,p);c.drawArc(cx+r*.55f,cy-r*.02f,cx+r*.85f,cy+r*.3f,0f,180f,false,p)}
                Icon.PHONE -> {c.drawRoundRect(cx-r*.55f,cy-r*.68f,cx+r*.55f,cy+r*.68f,r*.18f,r*.18f,p);c.drawCircle(cx,cy+r*.48f,.8f*d,fill);c.drawLine(cx-r*.2f,cy-r*.45f,cx+r*.2f,cy-r*.45f,p)}
                Icon.HEART -> {val path=Path().apply{moveTo(cx,cy+r*.55f);cubicTo(cx-r*.9f,cy, cx-r*.7f,cy-r*.65f,cx-r*.3f,cy-r*.48f);cubicTo(cx-r*.08f,cy-r*.4f,cx,cy-r*.2f,cx,cy-r*.05f);cubicTo(cx,cy-r*.2f,cx+r*.08f,cy-r*.4f,cx+r*.3f,cy-r*.48f);cubicTo(cx+r*.7f,cy-r*.65f,cx+r*.9f,cy,cx,cy+r*.55f)};c.drawPath(path,p)}
                Icon.SHIELD -> {val path=Path().apply{moveTo(cx,cy-r*.72f);lineTo(cx+r*.55f,cy-r*.5f);lineTo(cx+r*.45f,cy+r*.22f);cubicTo(cx+r*.32f,cy+r*.55f,cx,cy+r*.7f,cx,cy+r*.7f);cubicTo(cx,cy+r*.7f,cx-r*.32f,cy+r*.55f,cx-r*.45f,cy+r*.22f);lineTo(cx-r*.55f,cy-r*.5f);close()};c.drawPath(path,p)}
                Icon.HAND -> {c.drawCircle(cx,cy+r*.2f,r*.42f,p);c.drawLine(cx-r*.4f,cy-r*.1f,cx-r*.4f,cy-r*.6f,p);c.drawLine(cx-r*.15f,cy-r*.2f,cx-r*.15f,cy-r*.75f,p);c.drawLine(cx+r*.1f,cy-r*.18f,cx+r*.1f,cy-r*.72f,p);c.drawLine(cx+r*.35f,cy-r*.05f,cx+r*.35f,cy-r*.52f,p)}
                Icon.EYE -> {val path=Path().apply{moveTo(cx-r*.75f,cy);quadTo(cx,cy-r*.62f,cx+r*.75f,cy);quadTo(cx,cy+r*.62f,cx-r*.75f,cy);close()};c.drawPath(path,p);c.drawCircle(cx,cy,r*.2f,p)}
                Icon.MORE -> {c.drawCircle(cx-r*.35f,cy,.1f* w,fill);c.drawCircle(cx,cy,.1f*w,fill);c.drawCircle(cx+r*.35f,cy,.1f*w,fill)}
                Icon.BOOK -> {c.drawRect(cx-r*.5f,cy-r*.62f,cx,cy+r*.62f,p);c.drawRect(cx,cy-r*.62f,cx+r*.5f,cy+r*.62f,p);c.drawLine(cx-r*.32f,cy-r*.3f,cx-r*.08f,cy-r*.3f,p);c.drawLine(cx+r*.08f,cy-r*.3f,cx+r*.32f,cy-r*.3f,p)}
                Icon.BUILDING -> {c.drawRect(cx-r*.55f,cy-r*.5f,cx+r*.55f,cy+r*.6f,p);c.drawLine(cx-r*.75f,cy+r*.6f,cx+r*.75f,cy+r*.6f,p);for(i in -1..1){c.drawRect(cx+i*r*.25f,cy-r*.28f,cx+i*r*.25f+r*.08f,cy-r*.05f,p);c.drawRect(cx+i*r*.25f,cy+r*.08f,cx+i*r*.25f+r*.08f,cy+r*.31f,p)}}
                Icon.SETTINGS -> {c.drawCircle(cx,cy,r*.28f,p);c.drawCircle(cx,cy,r*.62f,p);for(i in 0..7){val a=i*Math.PI/4; c.drawLine(cx+Math.cos(a).toFloat()*r*.62f,cy+Math.sin(a).toFloat()*r*.62f,cx+Math.cos(a).toFloat()*r*.82f,cy+Math.sin(a).toFloat()*r*.82f,p)}}
                Icon.HELP -> {c.drawCircle(cx,cy,r*.65f,p);c.drawText("?",cx,cy+r*.3f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=fg;textSize=w*.72f;textAlign=Paint.Align.CENTER;typeface=Typeface.DEFAULT_BOLD})}
                Icon.BACK -> {c.drawLine(cx+r*.45f,cy,cx-r*.35f,cy,p);c.drawLine(cx-r*.35f,cy,cx-r*.02f,cy-r*.33f,p);c.drawLine(cx-r*.35f,cy,cx-r*.02f,cy+r*.33f,p)}
                Icon.SEARCH -> {c.drawCircle(cx-r*.12f,cy-r*.12f,r*.38f,p);c.drawLine(cx+r*.15f,cy+r*.15f,cx+r*.55f,cy+r*.55f,p)}
                Icon.CHEVRON -> {c.drawLine(cx-r*.12f,cy-r*.28f,cx+r*.18f,cy,cx-r*.12f,cy+r*.28f,p)}
                Icon.BELL -> {c.drawArc(cx-r*.42f,cy-r*.45f,cx+r*.42f,cy+r*.38f,190f,160f,false,p);c.drawLine(cx-r*.42f,cy+r*.08f,cx-r*.52f,cy+r*.25f,p);c.drawLine(cx+r*.42f,cy+r*.08f,cx+r*.52f,cy+r*.25f,p);c.drawLine(cx-r*.55f,cy+r*.25f,cx+r*.55f,cy+r*.25f,p);c.drawCircle(cx,cy+r*.42f,.9f*d,fill)}
            }
        }
    }

    private class SafeMapView(context: Context) : View(context) {
        private val road = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(210,218,222); strokeWidth=4f }
        private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(225,241,232) }
        private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(215,29,95) }
        private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(48,125,218) }
        override fun onDraw(c: Canvas) { c.drawColor(Color.rgb(238,244,239)); c.drawRect(width*.05f,height*.12f,width*.42f,height*.55f,green); c.drawRect(width*.58f,height*.46f,width*.95f,height*.9f,green); for(x in 0..width step 90)c.drawLine(x.toFloat(),0f,x.toFloat(),height.toFloat(),road); for(y in 0..height step 78)c.drawLine(0f,y.toFloat(),width.toFloat(),y.toFloat(),road); val pts=listOf(.24f to .28f,.57f to .33f,.78f to .48f,.36f to .56f,.63f to .7f,.8f to .8f); for((x,y) in pts){c.drawCircle(width*x,height*y,18f,marker);c.drawCircle(width*x,height*y,6f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE})}; c.drawCircle(width*.5f,height*.54f,24f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(55,48,125,218)});c.drawCircle(width*.5f,height*.54f,10f,blue) }
    }
}
