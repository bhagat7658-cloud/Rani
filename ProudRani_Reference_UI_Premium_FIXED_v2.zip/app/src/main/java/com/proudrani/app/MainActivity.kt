package com.proudrani.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val pink = Color.rgb(216, 26, 96)
    private val pinkDark = Color.rgb(173, 18, 73)
    private val pinkSoft = Color.rgb(255, 231, 239)
    private val bg = Color.rgb(255, 249, 251)
    private val white = Color.WHITE
    private val ink = Color.rgb(39, 34, 40)
    private val muted = Color.rgb(126, 115, 122)
    private val red = Color.rgb(232, 54, 58)
    private val purple = Color.rgb(120, 80, 230)
    private val green = Color.rgb(45, 174, 103)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
    private val pad get() = dp(16)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        splash()
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
    }

    private fun scroll(body: View, navSelected: Int? = null): View {
        val frame = FrameLayout(this)
        val scroller = ScrollView(this).apply {
            isFillViewport = true
            addView(body)
        }
        frame.addView(scroller, FrameLayout.LayoutParams(-1, -1))
        if (navSelected != null) addBottomNav(frame, navSelected)
        return frame
    }

    private fun splash() {
        val root = page().apply {
            gravity = Gravity.CENTER
            setPadding(pad, dp(28), pad, dp(28))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.proud_rani_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            alpha = 0f
            scaleX = .92f
            scaleY = .92f
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, dp(330)))
        root.addView(text("Safer Spaces\nBrighter Tomorrows", 20, ink, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            alpha = 0f
        })
        val bar = View(this).apply {
            setBackgroundColor(pink)
            scaleX = 0f
            pivotX = 0f
        }
        root.addView(bar, LinearLayout.LayoutParams(dp(150), dp(4)).apply { topMargin = dp(28) })
        setContentView(root)
        root.postDelayed {
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(500).start()
            root.getChildAt(1).animate().alpha(1f).setDuration(500).start()
            bar.animate().scaleX(1f).setDuration(900).start()
        }
        root.postDelayed({ login() }, 1700)
    }

    private fun login() {
        val body = page().apply {
            gravity = Gravity.TOP
            setPadding(pad, dp(28), pad, dp(20))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.proud_rani_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        body.addView(logo, LinearLayout.LayoutParams(-1, dp(190)))
        body.addView(text("Welcome to Proud Rani", 24, ink, true).apply { gravity = Gravity.CENTER })
        body.addView(text("A safer, stronger, more equal tomorrow.", 13, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(20))
        })
        body.addView(primaryButton("G   Continue with Google", pink) { home() })
        body.addView(text("OR", 12, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        })
        body.addView(edit("Enter mobile number"))
        body.addView(primaryButton("Send OTP", Color.rgb(248, 154, 186)) { home() })
        body.addView(text("By continuing, you agree to our\nTerms & Privacy Policy", 11, muted, false).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setPadding(0, dp(16), 0, 0)
        })
        setContentView(body)
    }

    private fun home() {
        val body = page().apply { setPadding(pad, dp(20), pad, dp(80)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val greeting = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        greeting.addView(text("Hello Rani 👋", 24, ink, true))
        greeting.addView(text("You are not alone.", 13, muted, false).apply { setPadding(0, dp(2), 0, 0) })
        header.addView(greeting)
        header.addView(iconBubble("♧", pinkSoft, pink, 30))
        body.addView(header)

        val grid = GridLayout(this).apply { columnCount = 2; setPadding(0, dp(14), 0, dp(4)) }
        grid.addView(actionCard("⚠", "SOS\nEmergency", red) { sos() })
        grid.addView(actionCard("▤", "Report\nIncident", pinkSoft, pinkDark) { report() })
        grid.addView(actionCard("⌖", "Find\nSafe Places", purple) { map() })
        grid.addView(actionCard("⚖", "Legal\nSupport", green) { resourcesPage() })
        body.addView(grid, LinearLayout.LayoutParams(-1, dp(230)))

        val qRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        qRow.addView(text("Quick Resources", 18, ink, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        qRow.addView(text("See All", 12, pink, true).apply { setOnClickListener { resourcesPage() } })
        body.addView(qRow)
        resourceRow("☎", "Women Helpline Numbers", "Important contact numbers") { resourcesPage() }
        resourceRow("♥", "Mental Health Support", "Counselling and support") { resourcesPage() }
        resourceRow("⚖", "Know Your Rights", "Guides and resources") { resourcesPage() }
        resourceRow("★", "Safety Tips", "Practical safety guidance") { resourcesPage() }
        setContentView(scroll(body, 0))
    }

    private fun report() {
        val body = page().apply { setPadding(pad, dp(14), pad, dp(90)) }
        addTopBar(body, "Report Incident")
        incidentRow(body, "👗", "Harassment", "Street, workplace, online etc.")
        incidentRow(body, "✊", "Assault", "Physical or sexual violence")
        incidentRow(body, "◉", "Stalking", "Repeated unwanted attention")
        incidentRow(body, "•••", "Others", "Any other incident")
        body.addView(primaryButton("Next", pink) { toast("Report flow ready — details can be added next") })
        setContentView(scroll(body, 2))
    }

    private fun map() {
        val body = page().apply { setPadding(0, dp(12), 0, dp(84)) }
        addTopBar(body, "Safe Places", true)
        val search = EditText(this).apply {
            hint = "Search safe places..."
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(14), 0, dp(14), 0)
            background = bgDrawable(white, 18)
            elevation = dp(2).toFloat()
        }
        body.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(pad, dp(4), pad, dp(8)) })
        body.addView(SafeMapView(this), LinearLayout.LayoutParams(-1, dp(420)))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = bgDrawable(white, 24)
            elevation = dp(2).toFloat()
        }
        card.addView(text("Women Help Centre", 17, ink, true))
        card.addView(text("2.1 km  •  Open 24x7", 12, Color.rgb(37, 165, 92), true).apply { setPadding(0, dp(3), 0, dp(10)) })
        card.addView(primaryButton("➜  Get Directions", pink) { toast("Directions can be connected next") })
        body.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(pad, dp(8), pad, 0) })
        setContentView(scroll(body, 1))
    }

    private fun resourcesPage() {
        val body = page().apply { setPadding(pad, dp(14), pad, dp(90)) }
        addTopBar(body, "Resources & Help")
        resourceRow(body, "☎", "Emergency Helplines", "Important contact numbers") { toast("112 • Women Helpline 181") }
        resourceRow(body, "⚖", "Legal Aid", "Free legal support") { toast("Legal support section") }
        resourceRow(body, "♥", "Mental Health Support", "Counselling and support") { toast("Support section") }
        resourceRow(body, "♣", "NGOs & Support Groups", "Verified organisations") { toast("Support groups") }
        resourceRow(body, "▤", "Safety Guides", "Tips and resources") { toast("Safety guides") }
        resourceRow(body, "▦", "Government Schemes", "Policies for women") { toast("Government schemes") }
        setContentView(scroll(body, 2))
    }

    private fun community() {
        val body = page().apply { setPadding(pad, dp(14), pad, dp(90)) }
        addTopBar(body, "Community", false, true)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(12)) }
        listOf("All", "Discussions", "Support", "Stories").forEachIndexed { i, s ->
            val chip = TextView(this).apply {
                text = s
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                setTextColor(if (i == 0) white else muted)
                gravity = Gravity.CENTER
                background = bgDrawable(if (i == 0) pink else white, 16)
                setPadding(dp(15), dp(8), dp(15), dp(8))
            }
            chips.addView(chip, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(7) })
        }
        body.addView(chips)
        postCard(body, "Rani123", "2 hours ago", "Sharing my story because I want other women to know they are not alone. 💜", "124   ♡   18   ◌")
        postCard(body, "SafeTogether", "5 hours ago", "Some important safety tips for travelling in the city. Let's keep each other safe! ✨", "86   ♡   10   ◌")
        postCard(body, "Aisha", "1 day ago", "This app is amazing. Finally, a space where we can support each other. ❤️", "210   ♡   25   ◌")
        setContentView(scroll(body, 3))
    }

    private fun profile() {
        val body = page().apply { setPadding(pad, dp(14), pad, dp(90)) }
        addTopBar(body, "My Profile", false, false, true)
        val profileHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(18))
        }
        val avatar = TextView(this).apply {
            text = "R"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(pinkDark)
            background = bgDrawable(pinkSoft, 60)
        }
        profileHeader.addView(avatar, LinearLayout.LayoutParams(dp(70), dp(70)))
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        p.addView(text("Rani", 19, ink, true))
        p.addView(text("+91 98765 43210", 12, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        profileHeader.addView(p)
        body.addView(profileHeader)
        resourceRow(body, "▣", "My Reports", "Your submitted reports") { toast("My reports") }
        resourceRow(body, "⌖", "Saved Places", "Places you saved") { map() }
        resourceRow(body, "✉", "My Posts", "Your community posts") { community() }
        resourceRow(body, "☎", "Emergency Contacts", "Trusted contacts") { resourcesPage() }
        resourceRow(body, "⚙", "App Settings", "Preferences") { toast("Settings") }
        resourceRow(body, "?", "Help & Feedback", "Support") { resourcesPage() }
        body.addView(primaryButton("Logout", Color.rgb(250, 223, 232)) { login() })
        setContentView(scroll(body, 4))
    }

    private fun sos() {
        AlertDialog.Builder(this)
            .setTitle("SOS Emergency")
            .setMessage("If you are in immediate danger, call emergency services first. Do you want to call 112 now?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Call 112") { _, _ -> dial("112") }
            .show()
    }

    private fun incidentRow(parent: LinearLayout, icon: String, title: String, subtitle: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(12), dp(10))
            background = bgDrawable(white, 18)
        }
        box.addView(iconBubble(icon, pinkSoft, pink, 23), LinearLayout.LayoutParams(dp(48), dp(48)))
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        copy.addView(text(title, 16, ink, true))
        copy.addView(text(subtitle, 12, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        box.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(text("›", 28, muted, false))
        parent.addView(box, LinearLayout.LayoutParams(-1, dp(76)).apply { bottomMargin = dp(10) })
    }

    private fun resourceRow(parent: LinearLayout, icon: String, title: String, subtitle: String, click: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(8), dp(8))
            background = bgDrawable(white, 16)
            setOnClickListener { click() }
        }
        box.addView(iconBubble(icon, pinkSoft, pink, 22), LinearLayout.LayoutParams(dp(44), dp(44)))
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        copy.addView(text(title, 14, ink, true))
        copy.addView(text(subtitle, 11, muted, false).apply { setPadding(0, dp(2), 0, 0) })
        box.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(text("›", 25, muted, false))
        parent.addView(box, LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(7) })
    }

    private fun postCard(parent: LinearLayout, name: String, time: String, bodyText: String, stats: String) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(11), dp(12), dp(11)); background = bgDrawable(white, 16) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = name.take(1); gravity = Gravity.CENTER; textSize = 14f; setTextColor(pinkDark); background = bgDrawable(pinkSoft, 50) }, LinearLayout.LayoutParams(dp(38), dp(38)))
        val who = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        who.addView(text(name, 13, ink, true)); who.addView(text(time, 10, muted, false))
        head.addView(who, LinearLayout.LayoutParams(0, -2, 1f)); head.addView(text("⋮", 22, muted, true))
        card.addView(head)
        card.addView(text(bodyText, 13, ink, false).apply { setPadding(0, dp(9), 0, dp(8)) })
        card.addView(text(stats, 11, muted, true))
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun actionCard(icon: String, label: String, background: Int, foreground: Int = white, click: () -> Unit): TextView {
        val v = TextView(this).apply {
            text = "$icon\n$label"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(foreground)
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            this.background = bgDrawable(background, 18)
            setOnClickListener { click() }
        }
        val spec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        v.layoutParams = GridLayout.LayoutParams(spec, spec).apply {
            width = 0
            height = dp(108)
            setMargins(dp(5), dp(5), dp(5), dp(5))
        }
        return v
    }

    private fun addTopBar(parent: LinearLayout, title: String, showSearch: Boolean = false, searchOnly: Boolean = false, settings: Boolean = false) {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(7)) }
        bar.addView(text("‹", 34, ink, true), LinearLayout.LayoutParams(dp(40), dp(48)).apply { gravity = Gravity.CENTER_VERTICAL })
        bar.addView(text(title, 18, ink, true).apply { gravity = Gravity.CENTER; }, LinearLayout.LayoutParams(0, dp(48), 1f))
        val right = if (settings) "⚙" else if (showSearch || searchOnly) "⌕" else ""
        if (right.isNotEmpty()) bar.addView(text(right, 24, muted, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(40), dp(48)))
        parent.addView(bar)
    }

    private fun addBottomNav(frame: FrameLayout, selected: Int) {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(white); elevation = dp(8).toFloat() }
        val labels = listOf("⌂\nHome", "⌖\nMap", "▣\nReport", "♣\nCommunity", "●\nProfile")
        labels.forEachIndexed { i, s ->
            val item = text(s, 10, if (i == selected) pink else muted, true).apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                setPadding(0, dp(6), 0, dp(4))
                setOnClickListener { when (i) { 0 -> home(); 1 -> map(); 2 -> report(); 3 -> community(); 4 -> profile() } }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, dp(62), 1f))
        }
        val params = FrameLayout.LayoutParams(-1, dp(62), Gravity.BOTTOM)
        frame.addView(nav, params)
    }

    private fun iconBubble(icon: String, background: Int, foreground: Int, size: Int): TextView = TextView(this).apply {
        text = icon
        textSize = (size * .52f)
        gravity = Gravity.CENTER
        setTextColor(foreground)
        this.background = bgDrawable(background, 50)
    }

    private fun primaryButton(label: String, color: Int, click: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(if (color == Color.rgb(248, 154, 186)) pinkDark else white)
        setTypeface(null, Typeface.BOLD)
        gravity = Gravity.CENTER
        background = bgDrawable(color, 18)
        elevation = dp(1).toFloat()
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) }
    }

    private fun edit(hint: String): EditText = EditText(this).apply {
        setHint(hint)
        textSize = 14f
        setSingleLine(true)
        setPadding(dp(16), 0, dp(16), 0)
        background = bgDrawable(white, 18)
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(8) }
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = s
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun bgDrawable(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dial(number: String) {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private class SafeMapView(context: android.content.Context) : View(context) {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(226, 238, 232) }
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(207, 216, 222); strokeWidth = 4f }
        private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(216, 26, 96) }
        private val center = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(44, 124, 217) }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            for (x in 0..width step 90) c.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), line)
            for (y in 0..height step 78) c.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), line)
            val points = listOf(.24f to .27f, .58f to .33f, .78f to .48f, .36f to .54f, .62f to .68f, .79f to .78f)
            for ((px, py) in points) {
                c.drawCircle(width * px, height * py, 18f, marker)
                c.drawCircle(width * px, height * py, 7f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            }
            c.drawCircle(width * .50f, height * .55f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(55, 44,124,217) })
            c.drawCircle(width * .50f, height * .55f, 10f, center)
        }
    }
}
