package com.genzofjkl.proudrani;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;

public class MainActivity extends Activity {
    private static final int LOCATION_REQ = 41;
    private static final String ANMOL = "9055501242";
    private static final String AAGRIYA = "9622191919";
    private static final String WHATSAPP = "919055501242"; // replace with official helpline when available

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        TextView sos = findViewById(R.id.sosButton);
        Button call112 = findViewById(R.id.call112), callAnmol = findViewById(R.id.callAnmol), callAagriya = findViewById(R.id.callAagriya), whatsapp = findViewById(R.id.whatsapp), share = findViewById(R.id.shareLocation);
        sos.setOnClickListener(v -> showSosDialog());
        call112.setOnClickListener(v -> dial("112"));
        callAnmol.setOnClickListener(v -> dial(ANMOL));
        callAagriya.setOnClickListener(v -> dial(AAGRIYA));
        whatsapp.setOnClickListener(v -> openWhatsApp());
        share.setOnClickListener(v -> shareLocation());
    }

    private void showSosDialog() {
        new AlertDialog.Builder(this).setTitle("Emergency SOS").setMessage("Are you in immediate danger? Choose an emergency action.")
                .setNegativeButton("Cancel", null).setPositiveButton("Call 112", (d,w) -> dial("112"))
                .setNeutralButton("Share Location", (d,w) -> shareLocation()).show();
    }

    private void dial(String number) {
        try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number))); }
        catch (Exception e) { Toast.makeText(this, "Unable to open phone dialer", Toast.LENGTH_SHORT).show(); }
    }

    private void openWhatsApp() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + WHATSAPP + "?text=" + Uri.encode("Hello Proud Rani, I need help.")));
            startActivity(i);
        } catch (Exception e) { Toast.makeText(this, "WhatsApp is not available", Toast.LENGTH_SHORT).show(); }
    }

    private void shareLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
            Toast.makeText(this, "Allow location, then tap Share My Location again", Toast.LENGTH_LONG).show(); return;
        }
        LocationManager lm = (LocationManager)getSystemService(LOCATION_SERVICE);
        Location loc = null;
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (SecurityException ignored) {}
        if (loc == null) { Toast.makeText(this, "Location unavailable. Turn on Location and try again.", Toast.LENGTH_LONG).show(); return; }
        String link = "https://maps.google.com/?q=" + loc.getLatitude() + "," + loc.getLongitude();
        Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, "I need help. My location: " + link); startActivity(Intent.createChooser(send, "Share location via"));
    }
}
