package com.proudrani.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    ProudView view; final int REQ=44;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(255,245,248)); view=new ProudView(this); setContentView(view);}
    void call(String number){ try { Intent i=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+number)); startActivity(i);} catch(Exception e){Toast.makeText(this,"Unable to open dialer",Toast.LENGTH_SHORT).show();}}
    void whatsapp(){ try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/919055501242?text="+Uri.encode("Proud Rani SOS / Women Safety Support"))); startActivity(i);}catch(Exception e){} }
    void sos(){
        new android.app.AlertDialog.Builder(this).setTitle("Emergency SOS").setMessage("Are you in immediate danger? We will open emergency calling options.")
        .setNegativeButton("Cancel",null).setPositiveButton("SOS",(d,w)->{call("112"); Toast.makeText(this,"Emergency call opened. Stay safe.",Toast.LENGTH_LONG).show();}).show();
    }
    class ProudView extends View {
        Paint p=new Paint(3); int screen=0; boolean splash=true; RectF r=new RectF();
        int pink=Color.rgb(205,28,93), dark=Color.rgb(70,20,45), pale=Color.rgb(255,235,242), purple=Color.rgb(112,72,218), green=Color.rgb(38,175,105);
        ProudView(Context c){super(c); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); setLayerType(View.LAYER_TYPE_SOFTWARE,null); postDelayed(()->{splash=false;screen=1;invalidate();},1700);}
        void bg(Canvas c,int color){c.drawColor(color);} void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); c.drawText(s,x,y,p);}
        void rr(Canvas c,float l,float t,float rr,float bb,float rad,int color){p.setColor(color);c.drawRoundRect(new RectF(l,t,rr,bb),rad,rad,p);}
        void center(Canvas c,String s,float y,float size,int color,boolean bold){p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); txt(c,s,(getWidth()-p.measureText(s))/2,y,size,color,bold);}
        void logo(Canvas c,float cx,float cy,float scale){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3*scale);p.setColor(pink);c.drawArc(new RectF(cx-55*scale,cy-45*scale,cx+45*scale,cy+55*scale),210,250,false,p);p.setStyle(Paint.Style.FILL);txt(c,"♔",cx-15*scale,cy-48*scale,25*scale,pink,true);center(c,"PROUD RANI",cy+75*scale,31*scale,dark,true);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); if(splash){bg(c,Color.rgb(255,224,235)); logo(c,getWidth()/2f, getHeight()/2f-35,1.15f); center(c,"Safer Spaces",getHeight()/2f+125,16,Color.DKGRAY,false); center(c,"Brighter Tomorrows",getHeight()/2f+150,16,Color.DKGRAY,false); rr(c,getWidth()/2f-70,getHeight()-55,getWidth()/2f+70,getHeight()-51,3,pink); return;} bg(c,Color.WHITE); if(screen==1)login(c); else if(screen==2)home(c); else if(screen==3)report(c); else if(screen==4)resources(c); else if(screen==5)community(c); else if(screen==6)profile(c); else if(screen==7)map(c); }
        void login(Canvas c){logo(c,getWidth()/2f,120,0.65f); center(c,"Welcome to Proud Rani",280,23,dark,true); center(c,"A safer, stronger, more equal tomorrow.",310,14,Color.GRAY,false); rr(c,32,350,getWidth()-32,405,18,pink); center(c,"Continue with Google",385,16,Color.WHITE,true); center(c,"OR",445,13,Color.GRAY,false); rr(c,32,470,getWidth()-32,525,16,Color.rgb(250,248,249)); txt(c,"☎   Enter mobile number",52,505,15,Color.GRAY,false); rr(c,32,540,getWidth()-32,592,18,Color.rgb(245,155,188)); center(c,"Send OTP",574,15,Color.WHITE,true); center(c,"By continuing, you agree to our",640,11,Color.GRAY,false); center(c,"Terms & Privacy Policy",661,11,pink,true); }
        void header(Canvas c,String title){txt(c,title,28,48,24,dark,true);}
        void home(Canvas c){rr(c,0,0,getWidth(),125,pink); txt(c,"Hello Rani 👋",24,42,23,Color.WHITE,true);txt(c,"You are not alone.",24,68,14,Color.WHITE,false);txt(c,"♧",getWidth()-55,52,26,Color.WHITE,true);
            tile(c,20,145,190,235,"🚨","SOS","Emergency",Color.rgb(230,45,48)); tile(c,205,145,375,235,"▤","Report","Incident",pale); tile(c,20,250,190,340,"●","Find","Safe Places",purple); tile(c,205,250,375,340,"⚖","Legal","Support",green);
            txt(c,"Quick Resources",22,382,19,dark,true);txt(c,"See All",getWidth()-72,382,13,pink,true); item(c,400,"☎","Women Helpline Numbers"); item(c,447,"♥","Mental Health Support");item(c,494,"✿","Know Your Rights");item(c,541,"✓","Safety Tips"); nav(c,590,0);
        }
        void tile(Canvas c,float l,float t,float rr,float b,String ic,String a,String btxt,int col){rr(c,l,t,rr,b,17,col);centerIn(c,ic,l,rr,t+34,25,Color.WHITE,true);centerIn(c,a,l,rr,t+62,14,col==pale?pink:Color.WHITE,true);centerIn(c,btxt,l,rr,t+80,13,col==pale?pink:Color.WHITE,false);}
        void centerIn(Canvas c,String s,float l,float rr,float y,float size,int color,boolean bold){p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));txt(c,s,(l+rr-p.measureText(s))/2,y,size,color,bold);}
        void item(Canvas c,float y,String ic,String s){rr(c,18,y,getWidth()-18,y+39,14,Color.rgb(255,248,250));txt(c,ic,31,y+26,18,pink,true);txt(c,s,62,y+25,14,dark,false);txt(c,"›",getWidth()-42,y+25,20,Color.GRAY,false);}
        void nav(Canvas c,float y,int active){String[] a={"⌂\nHome","⌖\nMap","▣\nReport","♣\nCommunity","●\nProfile"}; for(int i=0;i<5;i++){float x=(i+.5f)*getWidth()/5;String[] z=a[i].split("\\n");centerIn(c,z[0],x-35,x+35,y+18,18,i==active?pink:Color.GRAY,true);centerIn(c,z[1],x-35,x+35,y+40,10,i==active?pink:Color.GRAY,false);}}
        void report(Canvas c){header(c,"Report Incident");txt(c,"‹",18,50,35,dark,false); item2(c,90,"♟","Harassment","Street, workplace, online etc.");item2(c,165,"✊","Assault","Physical or sexual violence");item2(c,240,"◉","Stalking","Repeated unwanted attention");item2(c,315,"…","Others","Any other incident");rr(c,20,getHeight()-90,getWidth()-20,getHeight()-35,18,pink);center(c,"Next",getHeight()-55,15,Color.WHITE,true);}
        void item2(Canvas c,float y,String ic,String a,String b){rr(c,18,y,getWidth()-18,y+61,18,Color.rgb(255,248,250));txt(c,ic,32,y+38,20,pink,true);txt(c,a,72,y+27,15,dark,true);txt(c,b,72,y+48,11,Color.GRAY,false);txt(c,"›",getWidth()-40,y+37,22,Color.GRAY,false);}
        void resources(Canvas c){header(c,"Resources & Help");txt(c,"‹",18,50,35,dark,false);item2(c,85,"☎","Emergency Helplines","Important contact numbers");item2(c,155,"⚖","Legal Aid","Free legal support");item2(c,225,"♥","Mental Health Support","Counselling and support");item2(c,295,"♣","NGOs & Support Groups","Verified organisations");item2(c,365,"▣","Safety Guides","Tips and resources");item2(c,435,"▥","Government Schemes","Policies for women");}
        void community(Canvas c){header(c,"Community");txt(c,"⌕",getWidth()-52,50,30,dark,false);String[] tabs={"All","Discussions","Support","Stories"};for(int i=0;i<4;i++){rr(c,18+i*88,75,95+i*88,108,14,i==0?pink:Color.rgb(250,245,247));centerIn(c,tabs[i],18+i*88,95+i*88,97,11,i==0?Color.WHITE:dark,true);}post(c,130,"Rani123","Sharing my story because I want other women to know they are not alone. 💜","124   18");post(c,250,"SafeTogether","Some important safety tips for travelling in the city. Let's keep each other safe!","86   10");post(c,370,"Aisha","This app is amazing. Finally a space where we can support each other. ❤️","210   25");nav(c,getHeight()-75,3);}
        void post(Canvas c,float y,String n,String body,String stats){txt(c,n,55,y+18,14,dark,true);txt(c,"2 hours ago",55,y+36,10,Color.GRAY,false);txt(c,body,20,y+62,13,dark,false);txt(c,"♡  "+stats+"        ↗",22,y+100,12,Color.GRAY,false);}
        void profile(Canvas c){header(c,"My Profile");txt(c,"⚙",getWidth()-55,50,22,dark,false);rr(c,25,82,105,162,40,pale);centerIn(c,"♛",25,105,135,28,pink,true);txt(c,"Rani",125,116,22,dark,true);txt(c,"+91 98765 43210",125,140,13,Color.GRAY,false);item(c,190,"▣","My Reports");item(c,240,"⌖","Saved Places");item(c,290,"▰","My Posts");item(c,340,"♟","Emergency Contacts");item(c,390,"⚙","App Settings");item(c,440,"?","Help & Feedback");rr(c,35,505,getWidth()-35,555,15,pale);center(c,"Logout",537,14,pink,true);nav(c,getHeight()-75,4);}
        void map(Canvas c){bg(c,Color.rgb(224,239,225));rr(c,18,25,getWidth()-18,78,18,Color.WHITE);txt(c,"⌕  Search safe places...",34,59,14,Color.GRAY,false);for(int i=0;i<7;i++){float x=45+(i*57)%300,y=150+(i*93)%390; p.setColor(pink);c.drawCircle(x,y,9,p);c.drawCircle(x,y,3,p); }rr(c,18,getHeight()-190,getWidth()-18,getHeight()-20,20,Color.WHITE);txt(c,"Women Help Centre",35,getHeight()-150,17,dark,true);txt(c,"2.1 km",35,getHeight()-127,12,Color.GRAY,false);txt(c,"● Open 24x7",35,getHeight()-105,11,green,true);rr(c,35,getHeight()-88,getWidth()-35,getHeight()-38,15,pink);center(c,"↗  Get Directions",getHeight()-56,14,Color.WHITE,true);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true;float x=e.getX(),y=e.getY();
            if(splash)return true; if(screen==1){if(y>330&&y<610){screen=2;invalidate();}return true;}
            if(screen==2){if(y>135&&y<245&&x<200){sos();return true;} if(y>135&&y<245&&x>200){screen=3;} else if(y>245&&y<350&&x<200){screen=7;} else if(y>245&&y<350&&x>200){screen=4;} else if(y>getHeight()-90){int n=(int)(x/(getWidth()/5));screen=n==0?2:n==1?7:n==2?3:n==3?5:6;}invalidate();return true;}
            if(screen==3||screen==4){if(y<75){screen=2;invalidate();}return true;} if(screen==5||screen==6||screen==7){if(y>getHeight()-100){int n=(int)(x/(getWidth()/5));screen=n==0?2:n==1?7:n==2?3:n==3?5:6;invalidate();} else if(screen==6&&y>330&&y<410){call("9055501242");}return true;}return true; }
    }
}
